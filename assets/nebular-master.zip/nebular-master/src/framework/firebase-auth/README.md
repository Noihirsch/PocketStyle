### @nebular/firebase-auth module, more details https://akveo.github.io/nebular/
