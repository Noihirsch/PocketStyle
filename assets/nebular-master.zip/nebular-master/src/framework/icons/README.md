# Nebular icons - amazing icons crafted with love by Akveo team

### This package is deprecated. Please check [Eva Icons](https://akveo.github.io/eva-icons/) and new [nb-icon](https://akveo.github.io/nebular/docs/components/icon) component. 
